function encryptText() {
    const inputText = document.getElementById('inputText').value;
    const encryptedText = btoa(inputText);
    displayEncryptedText(encryptedText);
}

function decryptText() {
    const encryptedText = document.getElementById('inputText').value;
    try {
        const decryptedText = atob(encryptedText); // Desencriptación base64
        displayEncryptedText(decryptedText);
    } catch (e) {
        alert("El texto no está en un formato válido para desencriptar.");
    }
}

function displayEncryptedText(text) {
    const placeholderImage = document.getElementById('placeholderImage');
    const encryptedTextElement = document.getElementById('encryptedText');

    if (text) {
        placeholderImage.style.display = 'none'; // Ocultar la imagen
        encryptedTextElement.style.display = 'block'; // Mostrar el texto
        encryptedTextElement.textContent = text;
    } else {
        placeholderImage.style.display = 'block'; // Mostrar la imagen si no hay texto
        encryptedTextElement.style.display = 'none'; // Ocultar el texto
    }
}